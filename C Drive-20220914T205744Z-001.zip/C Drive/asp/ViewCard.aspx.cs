﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using System.Data.SqlClient;
using System.Data.OleDb;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class ViewCard : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }
//    protected System.Timers.Timer _timer;

//    private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
//    {
//        // Do whatever you want to do on each tick of the timer
//        TextBox1.Text = "OKKK";
//}

        protected void Btn_Pending_job_Click(object sender, EventArgs e)
    {
        CrystalReportViewer1.Visible = false;
        GridView1.Visible = true;
        callParaFunction(DateTime.Now.Date, false);
//Total Card
        int tn = countCard();
        lbl_tcard.Text  = tn.ToString();
        int tam = tn * 20;
        lbl_tamount.Text = tam.ToString();
  
    }
    protected void Btn_Completed_Click(object sender, EventArgs e)
    {
        CrystalReportViewer1.Visible = false;
        GridView1.Visible = true ;
        callParaFunction(DateTime.Now.Date, true);
  //Total Card
        int tn = countCard();
        lbl_tcard.Text = tn.ToString();
        int tam = tn * 20;
        lbl_tamount.Text = tam.ToString();
  
    }
    protected void Btn_Print_Record_Click(object sender, EventArgs e)
    {
        GridView1.Visible = false;
        CrystalReportViewer1.Visible = true ;
        showReportSQL();
        //Total Card
        int tn = countCard();
        lbl_tcard.Text = tn.ToString();
        int tam = tn * 20;
        lbl_tamount.Text = tam.ToString();
 
    }
      
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        CrystalReportViewer1.Visible = false;
        GridView1.Visible = true;
        callParaFunction(DateTime.Now.Date, false);
        //GridView1.Columns..HeaderText = "Sno";
    }

    public void showReportSQL()
    {
        string str = "Data Source=p1-8b050d32a27d\\sqlexpress;Initial Catalog=card;Integrated Security=True";
        SqlConnection con = new SqlConnection(str);
        con.Open();

        //string currentDate;
        //currentDate = TextBox1.Text;

        ReportDocument rptDoc = new ReportDocument();
        DataSet ds = new DataSet();

        DataTable dt = new DataTable();

        // dt.TableName = "Crystal";

        SqlCommand cmd = new SqlCommand("select * from card_Data where cid like 'C-%' and cstatus = 1 and pdate = '" + DateTime.Now.Date + "' ", con);
        cmd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        da.Fill(dt);
        ds.Merge(dt);
        rptDoc.Load("C://asp//CrystalReport_CP.rpt");
        // rptDoc.Load(Server.MapPath("http://172.20.10.46/PRINT/CrystalReport1.rpt"));
        rptDoc.SetDataSource(ds);
        CrystalReportViewer1.ReportSource = rptDoc;
        rptDoc.SetParameterValue("pdate", DateTime .Now .Date );
       
        //rptDoc.SetParameterValue("curDate", "18/08/2012");

        con.Close();

    }


    //public void showReportDB()
    //{
    //    string strLogConnectionString = @"Provider=vfpoledb;Data Source= C:\ASP\CIMENG.DBF;Collating Sequence=machine;Mode=ReadWrite;";

    //    OleDbConnection strConLog = new OleDbConnection(strLogConnectionString);
    //    strConLog.Open();

    //   // string currentDate;
    //   // currentDate = string.Format("{0:dd/MM/yyyy}", DateTime.Now);
    //    string currentDate;
    //    currentDate = TextBox1 .Text;
       
    //    ReportDocument rptDoc = new ReportDocument();
    //    DataSet ds = new DataSet();

    //    DataTable dt = new DataTable();

    //    // dt.TableName = "Crystal";

    //    OleDbCommand cmd = new OleDbCommand("select * from CIMENG where pdate = '" + currentDate + "' ", strConLog);
    //    cmd.CommandType = CommandType.Text;
    //    OleDbDataAdapter da = new OleDbDataAdapter();
    //    da.SelectCommand = cmd;
    //    da.Fill(dt);
    //    ds.Merge(dt);
    //    rptDoc.Load("C://asp//CrystalReport_CP.rpt");
    //   // rptDoc.Load(Server.MapPath("http://172.20.10.46/PRINT/CrystalReport1.rpt"));
    //    rptDoc.SetDataSource(ds);
    //    CrystalReportViewer1.ReportSource = rptDoc;
    //    rptDoc.SetParameterValue("pdate", currentDate);
    //    //rptDoc.SetParameterValue("curDate", "18/08/2012");

    //    strConLog.Close();

    //}


    public void callParaFunction(DateTime cuDate, bool cuStatus)
    {
        string str = "Data Source=p1-8b050d32a27d\\sqlexpress;Initial Catalog=card;Integrated Security=True";
        SqlConnection con = new SqlConnection(str);
        SqlCommand cmd = new SqlCommand("sp_getData", con);
        con.Open();
        cmd.CommandType = CommandType.StoredProcedure;

        //cuDate = DateTime .Now.Date ;
        //cuStatus = true;
        //string currentDate;
        //currentDate = string.Format("{0:dd/MM/yyyy}", DateTime.Now);
        cmd.Parameters.Add("@_pdate", SqlDbType.DateTime).Value = cuDate;
        cmd.Parameters.Add("@_cstatus", SqlDbType.Bit).Value = cuStatus;

        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds, "card_data");
        this.GridView1.DataSource = ds;
        this.GridView1.DataBind();
        //cmd.ExecuteNonQuery();
        con.Close();



        //string strLogConnectionString = @"Provider=vfpoledb;Data Source= C:\ASP\CIMENG.DBF;Collating Sequence=machine;Mode=ReadWrite;";

        //OleDbConnection strConLog = new OleDbConnection(strLogConnectionString);
        //strConLog.Open();

        ////string currentDate;
        ////currentDate = string.Format("{0:dd/MM/yyyy}", DateTime.Now);


        //OleDbCommand cmd = new OleDbCommand("select * from CIMENG where pdate = '"+TextBox1 .Text  +"' ", strConLog);
        //cmd.CommandType = CommandType.Text;
        //OleDbDataAdapter da = new OleDbDataAdapter();
        //da.SelectCommand = cmd;
        //DataSet ds = new DataSet();
        //da.Fill(ds);


        //this.GridView1.DataSource = ds;
        //this.GridView1.DataBind();

        //strConLog.Close();
    }

    public int countCard()
    {

        string strLogConnectionString = @"Provider=vfpoledb;Data Source= C:\ASP\CIMENG.DBF;Collating Sequence=machine;Mode=ReadWrite;";

        OleDbConnection strConLog = new OleDbConnection(strLogConnectionString);
        strConLog.Open();
        string currentDate;
        currentDate = string.Format("{0:dd/MM/yyyy}", DateTime.Now);
        OleDbCommand countquery = new OleDbCommand("select count(CARDNUM) from CIMENG where pdate = '" + currentDate + "' and status = 1 ", strConLog);
        countquery.ExecuteScalar();
        string count = countquery.ExecuteScalar().ToString();
        int a = Convert.ToInt32(count);
        return a;
    }

    public void fillPendingGridView()
    {
        string strLogConnectionString = @"Provider=vfpoledb;Data Source= C:\ASP\CIMENG.DBF;Collating Sequence=machine;Mode=ReadWrite;";

        OleDbConnection strConLog = new OleDbConnection(strLogConnectionString);
        strConLog.Open();

        string currentDate;
        currentDate = string.Format("{0:dd/MM/yyyy}", DateTime.Now);


        OleDbCommand cmd = new OleDbCommand("select * from CIMENG where pdate = '" + currentDate + "' and status = 0 ", strConLog);
        cmd.CommandType = CommandType.Text;
        OleDbDataAdapter da = new OleDbDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);

        this.GridView1.DataSource = ds;
        this.GridView1.DataBind();

        strConLog.Close();
    }

    public void fillCompleteJobGridView()
    {
        string strLogConnectionString = @"Provider=vfpoledb;Data Source= C:\ASP\CIMENG.DBF;Collating Sequence=machine;Mode=ReadWrite;";

        OleDbConnection strConLog = new OleDbConnection(strLogConnectionString);
        strConLog.Open();

        string currentDate;
        currentDate = string.Format("{0:dd/MM/yyyy}", DateTime.Now);

        OleDbCommand cmd = new OleDbCommand("select * from CIMENG where pdate = '" + currentDate + "' and status = 1 ", strConLog);
        cmd.CommandType = CommandType.Text;
        OleDbDataAdapter da = new OleDbDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);

        this.GridView1.DataSource = ds;
        this.GridView1.DataBind();

        strConLog.Close();
    }

   }
