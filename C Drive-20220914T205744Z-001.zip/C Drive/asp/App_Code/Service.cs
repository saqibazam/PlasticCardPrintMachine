﻿using System;

using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;


using System.Data;
using System.Data.SqlClient;
//using System.Data.OleDb;

[WebService(Namespace = "http://PrintCard/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class Service : System.Web.Services.WebService
{
    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    //public string HelloWorld() {
    //    return "Hello World";
    //}
    public string InsertData(string CardNo, string Name, string DOB, string DeptID, string ip)
    {
        try
        {
            string str = "Data Source =P1-8B050D32A27D\\SQLEXPRESS; Initial Catalog = card ;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("sp_insertData", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@_cardnum", SqlDbType.VarChar).Value = CardNo;
            cmd.Parameters.Add("@_cname", SqlDbType.VarChar).Value = Name;
            cmd.Parameters.Add("@_dob", SqlDbType.VarChar).Value = DOB;
            cmd.Parameters.Add("@_deptid", SqlDbType.VarChar).Value = DeptID;
            cmd.Parameters.Add("@_pdate", SqlDbType.DateTime).Value = DateTime.Now.Date;
            cmd.Parameters.Add("@_cid", SqlDbType.VarChar).Value = ip;
            cmd.Parameters.Add("@_cstatus", SqlDbType.Bit).Value = false;
            cmd.ExecuteNonQuery();
            con.Close();
            return "Data has been Inserted";
        }
        catch (Exception)
        {

            return "Error: Card Already Send";

        }
        }

    
}
