



right click on folder > Properties > select .Net Frame Work
In edit configuration select C# coding.


run this command on the visual studio command prompt

aspnet_regiis -i

Optional work
--------------
Error Solution (The 'vfpoledb' provider is not registered on the local machine.)



Click on Properties on the solution explorer side
On Build Target Select .Net Frame Work 2.0
--------------

Error Solution (The 'vfpoledb' provider is not registered on the local machine.)


Add 
added this line:

<identity impersonate="true" userName="DomainName\xxxxx" password="xxxxx"/>

to the System.web tag in my web.config file - using a valid username & password for 
our domain and making sure that the user has access to the shares on which the FoxPro 
DBFs reside.

------------------
Error Solution (The 'vfpoledb' provider is not registered on the local machine.)

1.  If the Driver is installed, uninstall it.
2.  Open a Command Prompt running "As Administrator"
3.  Run the VFPOLEDBSetup.msi from the command prompt.