﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Threading;
using System.Data.OleDb;
using System.Diagnostics;

public partial class PrintCard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Start_Print_Click(object sender, EventArgs e)
    {
        processCard();
    }

    public int countCard()
    {

        string strLogConnectionString = @"Provider=vfpoledb;Data Source= C:\ASP\CIMENG.DBF;Collating Sequence=machine;Mode=ReadWrite;";

        OleDbConnection strConLog = new OleDbConnection(strLogConnectionString);
        strConLog.Open();
        //string pdate = Convert .ToString (DateTime.Now);
        //string pdate = DateTime.Now.Date.ToShortDateString();
        OleDbCommand countquery = new OleDbCommand("select count(CARDNUM) from CIMENG", strConLog);
        countquery.ExecuteScalar();
        string count = countquery.ExecuteScalar().ToString();
        int a = Convert.ToInt32(count);
        return a;
    }


    public void PrintBatchCard()
    {

        Process p = new Process();
        //p.StartInfo.FileName = "CMD.exe"; //Execute command
        p.StartInfo.FileName = @"c:\asp\card.bat";
        p.StartInfo.WorkingDirectory = @"c:\asp";
        int count = countCard();
        p.StartInfo.Arguments = count.ToString();
        p.Start();
        p.WaitForExit();

    }

    public void callCard()
    {
        int a = countCard();
        Thread.Sleep(10000);
        int b = countCard();
        if (b > a)
        {
            PrintBatchCard();

        }

    }

    public void processCard()
    {
        //Print Card on Thread with Time Interval
        ThreadStart operation = new ThreadStart(callCard);
        Thread[] theThreads = new Thread[500];

        for (int x = 0; x < 500; ++x)
        {
            // Creates, but does not start, a new thread 
            theThreads[x] = new Thread(operation);

            // Starts the work on a new thread 
            theThreads[x].Start();
            Thread.Sleep(10000);

        }

        // Wait for each thread to complete 
        foreach (Thread t in theThreads)
        {
            t.Join();
            //t.Abort();

        }


    }

}
