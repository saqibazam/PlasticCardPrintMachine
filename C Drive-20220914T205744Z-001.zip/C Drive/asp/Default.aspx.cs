﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
     Service ws = new Service();
        //TextBox1 .Text = ws.HelloWorld();

        //TextBox1.Text = ws.HelloWorld2("Hello ", "PHP WebServices");

        string CardNo = "11111111111";
        string Name = "ABDUL WAHAB KHAN";
        string DOB = "M-55";
        string DeptID = "SERGICAL-01";
        string ip = "C-2";

        TextBox1.Text = ws.InsertData(CardNo, Name, DOB, DeptID,ip); 
    }
}
