﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


using System.Threading;
using System.Data.OleDb;
using System.Diagnostics;

namespace CardPrint
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_Start_Click(object sender, EventArgs e)
        {
            StartJob();
        }

        private void btn_Stop_Click(object sender, EventArgs e)
        {
            StopJob();
        }

        private bool _isRunning = false;
        private int _interval = 1;
        //private int count2;
        //then in your start method create a new thread

        public void StartJob()
        {
            btn_Start.Enabled = false;
            ThreadStart oThreadStart = new ThreadStart(DoWork);
            Thread t = new Thread(oThreadStart);

            _isRunning = true;

            t.Start();
        }

        public void StopJob()
        {
            btn_Stop.Enabled = false;
            _isRunning = false;
        }

        private void DoWork()
        {
            while (_isRunning)
            {
                // do work
                Thread.Sleep(_interval);
                getCard(); // get min(sno), status = 0 and currentDate Card



                if (_sno != null && (_cstatus == false))
                {
                    insertDBF(); // insert this in DBF
                    PrintBatchCard(); //print this card
                    updatePrintCard(); // update in SQLServer DB status = 1 of this card
                    _cstatus = true;
                }
                //int snum = Convert.ToInt32(_sno);
                //if (_sno != null && snum == snum + 1 && (_cstatus == false))
                //    {
                //        insertDBF(); // insert this in DBF
                //        PrintBatchCard(); //print this card
                //        updatePrintCard(); // update in SQLServer DB status = 1 of this card
                //    }

            }

            Thread.CurrentThread.Join();
        }

        private string _sno;
        private string _cardnum;
        private string _cname;
        private string _dob;
        private string _deptid;
        private string _pdate;
        private string _cid;
        private bool _cstatus;


        private void getCard()
        {

            string str = "Data Source=p1-8b050d32a27d\\SQLEXPRESS;Initial Catalog=card;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);

            SqlCommand countMin = new SqlCommand("select min(sno) from card_Data where cid like 'C-%' and  cstatus = 0 and pdate = '" + DateTime.Now.Date + "'", con);
            con.Open();
            countMin.ExecuteScalar();
            string _countMin = countMin.ExecuteScalar().ToString();
            //int c = Convert.ToInt32(_countMin);


            SqlCommand cmd = new SqlCommand("select sno, cardnum,cname, dob,deptid,pdate,cid,cstatus from card_Data where sno = '" + _countMin + "' and cstatus = 0 and pdate = '" + DateTime.Now.Date + "'", con);
            
            //select min(sno) as sno, cardnum,cname, dob,deptid,pdate,cid,cstatus  from card_Data where cstatus = 0 and pdate = '" + DateTime.Now.Date + "' group by cardnum,cname, dob,deptid,pdate,cid,cstatus ", con);
            SqlDataReader reader = cmd.ExecuteReader();

           while (reader.Read())
            {
                _sno = reader["sno"].ToString();
                _cardnum = reader["cardnum"].ToString();
                _cname = reader["cname"].ToString();
                _dob = reader["dob"].ToString();
                _deptid = reader["deptid"].ToString();
                _pdate = reader["pdate"].ToString();
                _cid = reader["cid"].ToString();

                string _cstatus1 = reader["cstatus"].ToString();
                _cstatus = Convert.ToBoolean(_cstatus1);
            }
            reader.Close();
            con.Close();

        }
        public void updatePrintCard()
        {
            int s_no = Convert.ToInt32(_sno);
            string str = "Data Source=p1-8b050d32a27d\\SQLEXPRESS;Initial Catalog=card;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("update card_Data set cstatus = 1 where cstatus = 0 and pdate = '" + DateTime.Now.Date + "' and sno = " + _sno + " ", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void insertDBF()
        {


            //code to insert data in dbf file....
            string strLogConnectionString = @"Provider=vfpoledb;Data Source= C:\ASP\CIMENG.DBF;Collating Sequence=machine;Mode=ReadWrite;";

            OleDbConnection strConLog = new OleDbConnection(strLogConnectionString);
            strConLog.Open();
            //string pdate = Convert .ToString (DateTime.Now);
            //string  pdate = DateTime.Now.Date.ToShortDateString();
            string currentDate;
            currentDate = string.Format("{0:dd/MM/yyyy}", DateTime.Now);

            //OleDbCommand maxquery = new OleDbCommand("select MAX(SNO) from CIMENG", strConLog);
            //maxquery.ExecuteScalar();
            //string max = maxquery.ExecuteScalar().ToString();
            //int s_no = Convert.ToInt32(max) + 1;


            OleDbCommand oComm = new OleDbCommand("Insert into CIMENG(CARDNUM,NAME,DOB,DEPTID,PDATE,STATUS,USER) values('" + _cardnum + "','" + _cname + "','" + _dob + "','" + _deptid + "','" + currentDate + "', 1,'" + _cid + "')", strConLog);
            oComm.ExecuteNonQuery();
            strConLog.Close();
            // public string InsertData(string cardnum, string name, string dob, string deptid, DateTime pdate, string uid, bool status); 



        }


       


        public int countCard()
        {

            string strLogConnectionString = @"Provider=vfpoledb;Data Source= C:\ASP\CIMENG.DBF;Collating Sequence=machine;Mode=ReadWrite;";

            OleDbConnection strConLog = new OleDbConnection(strLogConnectionString);
            strConLog.Open();
            //string pdate = Convert .ToString (DateTime.Now);
            //string pdate = DateTime.Now.Date.ToShortDateString();
           // string currentDate;
          //  currentDate = string.Format("{0:dd/MM/yyyy}", DateTime.Now);


            //OleDbCommand cmd = new OleDbCommand("select * from CIMENG where pdate = '" + currentDate + "' and status = 0 ", strConLog);
            OleDbCommand countquery = new OleDbCommand("select count(CARDNUM) from CIMENG  ", strConLog);
            countquery.ExecuteScalar();
            string count = countquery.ExecuteScalar().ToString();
            int a = Convert.ToInt32(count);
            return a;
        }







        public void PrintBatchCard()
        {

            Process p = new Process();
            //p.StartInfo.FileName = "CMD.exe"; //Execute command
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            p.StartInfo.FileName = @"c:\asp\card.bat";
            p.StartInfo.WorkingDirectory = @"c:\asp";
            int count = countCard();
            p.StartInfo.Arguments = count.ToString();
            p.StartInfo.CreateNoWindow = true;
            p.Start();
            p.StartInfo.WindowStyle = ProcessWindowStyle.Minimized;
            p.WaitForExit();





            //Process p = new Process();
            ////p.StartInfo.FileName = "CMD.exe"; //Execute command
            //p.StartInfo.FileName = @"c:\asp\card.bat";
            //p.StartInfo.WorkingDirectory = @"c:\asp";
            //int count = countCard();
            //p.StartInfo.Arguments = count.ToString();
            //p.Start();
            //p.WaitForExit();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
        
            Application.ExitThread();
            Application.Exit();
       
        }


        




    }
}
