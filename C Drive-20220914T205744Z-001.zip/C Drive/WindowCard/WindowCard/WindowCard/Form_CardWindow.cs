﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowCard
{
    public partial class Form_CardWindow : Form
    {
        private DialogResult dlgResult;

        public Form_CardWindow()
        {
            InitializeComponent();
        }

        private void Form_CardWindow_Load(object sender, EventArgs e)
        {
            try {
            // TODO: This line of code loads data into the 'cardDataSet1.card_data' table. You can move, or remove it, as needed.
           // this.card_dataTableAdapter.Fill(this.cardDataSet1.card_data);
            // TODO: This line of code loads data into the 'cardDataSet.card_dailytotal' table. You can move, or remove it, as needed.
           // this.card_dailytotalTableAdapter.Fill(this.cardDataSet.card_dailytotal);
            this.card_dataTableAdapter.FillByCdate(this.cardDataSet1.card_data, Convert .ToDateTime ( pdateDateTimePicker.Text)   );
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
            }
            }

        private void card_dailytotalBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try {
            this.Validate();
            this.card_dailytotalBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.cardDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
            }
        }

    
        private void button_Load_Click(object sender, EventArgs e)
        {
            try
            {
                label_heading.Text = "Load Current Date Record";
                this.card_dataTableAdapter.FillByCdate(this.cardDataSet1.card_data, Convert .ToDateTime ( pdateDateTimePicker.Text) );
                
                label_TotalCard.Text = this.card_dataTableAdapter.CountTotalCard(pdateDateTimePicker.Value).ToString ();
                if (label_TotalCard.Text == "") label_TotalCard.Text = "0"; 
                label_TrueCard.Text = this.card_dataTableAdapter.CountCard(true, pdateDateTimePicker.Value).ToString();
                if (label_TrueCard.Text == "") label_TrueCard.Text = "0";
                label_FalseCard.Text = this.card_dataTableAdapter.CountCard(false, pdateDateTimePicker.Value).ToString();
                if (label_FalseCard.Text == "") label_FalseCard.Text = "0";
                
            }
            catch (Exception ex)            {
                MessageBox.Show(Convert.ToString(ex));
            }
            }

       

        private void button_Update_Click(object sender, EventArgs e)
        {
            try {
            label_heading.Text = "Updated Record";
            this.card_dataTableAdapter.UpdateQuery_Status(cstatusCheckBox.Checked, Convert.ToDateTime(pdateDateTimePicker.Text), cardnumTextBox.Text);
            this.card_dataTableAdapter.FillByCdate(this.cardDataSet1.card_data, Convert.ToDateTime(pdateDateTimePicker.Text));
            label_TotalCard.Text = this.card_dataTableAdapter.CountTotalCard(pdateDateTimePicker.Value).ToString();
            label_TrueCard.Text =  this.card_dataTableAdapter.CountCard(true, pdateDateTimePicker.Value).ToString ();
            label_FalseCard.Text = this.card_dataTableAdapter.CountCard(false, pdateDateTimePicker.Value).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
            }
            }

        private void button_FalseCard_Click(object sender, EventArgs e)
        {
            try
            {
                label_heading.Text = "False Record";
                this.card_dataTableAdapter.FillByFalse(this.cardDataSet1.card_data, Convert.ToDateTime(pdateDateTimePicker.Text));
                label_FalseCard.Text = this.card_dataTableAdapter.CountCard(false, pdateDateTimePicker.Value).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
            }
            
            }

        private void button_PrintDailyReport_Click(object sender, EventArgs e)
        {
        try
        {
            CrystalReport_DailyReport CDR = new CrystalReport_DailyReport();
            CDR .Load ("C:\\WindowCard\\WindowCard\\WindowCard\\CrystalReport_DailyReport.rpt");
            crystalReportViewer1 .ReportSource = CDR ;
            crystalReportViewer1 .DisplayToolbar =  true ;
            crystalReportViewer1 .DisplayGroupTree = false ;
            CDR.SetParameterValue("_pdate",pdateDateTimePicker .Value );
            tabControl1.SelectTab(1);


        }
            catch (Exception Ex)
            {
                //MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show(Convert.ToString(Ex));
            }
        }

       

        private void button_InsertMonthlyReport_Click(object sender, EventArgs e)
        {
            
             dlgResult = MessageBox.Show("Do you want to Insert this record?", "Insert Record", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
             if (dlgResult == DialogResult.Yes)
             {
                 try
                 {
                     //Insert Record
                     this.card_dailytotalTableAdapter.Insert_Card_DailyTotal(Convert.ToDateTime(pdateDateTimePicker.Text), Convert.ToInt32(label_TotalCard.Text), Convert.ToInt32(textBox_ExcessAmount.Text), Convert.ToInt32(textBox_ShortAmount.Text), Convert.ToInt32(textBox_tAmount.Text), Convert.ToInt32(textBox_ActualCard.Text), Convert.ToInt32(textBox_RejectCard.Text));
                    
                     MessageBox.Show("Record has been inserted, click OK to continue...", "Insert Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                 }
                 catch 
                 {
                   //  MessageBox.Show("Record Already Inserted, click OK to continue...", "Already Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // MessageBox.Show(Ex.ToString () );
                     dlgResult = MessageBox.Show("This Record Already Inserted, Do you want to Update it", "Already Inserted", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                      if (dlgResult == DialogResult.Yes)
                      {
                          try 
                          {
                          //Update Record
                              this.card_dailytotalTableAdapter.UpdateCardDailyTotal(Convert.ToInt32(label_TotalCard.Text), Convert.ToInt32(textBox_ExcessAmount.Text), Convert.ToInt32(textBox_ShortAmount.Text), Convert.ToInt32(textBox_tAmount.Text), Convert.ToInt32(textBox_ActualCard.Text), Convert.ToInt32(textBox_RejectCard.Text), Convert.ToDateTime(pdateDateTimePicker.Text));
                              MessageBox.Show("Record Updated Successfully");
                          }
                          catch (Exception Ex)
                          { MessageBox.Show(Ex.ToString()); }
                      }

                 }

             }
            
   }

        private void button_MonthlyReport_Click(object sender, EventArgs e)
        {
            try
            {
                CrystalReport_MonthlyReport CMR = new CrystalReport_MonthlyReport();
                //CrystalReport_DailyReport CDR = new CrystalReport_DailyReport();
                CMR.Load("C:\\WindowCard\\WindowCard\\WindowCard\\CrystalReport_MonthlyReport.rpt");
                crystalReportViewer_MonthlyReport.ReportSource = CMR;
                crystalReportViewer_MonthlyReport.DisplayToolbar = true;
                crystalReportViewer_MonthlyReport.DisplayGroupTree = false;
                CMR.SetParameterValue("DateTo", Convert.ToDateTime(dateTimePickerTo.Text));
                CMR.SetParameterValue("DateFrom", Convert.ToDateTime(dateTimePickerFrom.Text));

                //string strFormula = "";
                //strFormula = "{View_CardTotal.card_date} >=#" + dateTimePickerTo.Value + "# and {View_CardTotal.card_date} <= #" + dateTimePickerFrom.Value + "#";
                //crystalReportViewer_MonthlyReport.SelectionFormula = strFormula;

            }
            catch (Exception Ex)
            {
                //MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show(Convert.ToString(Ex));
            }
        }
    
    }
}
