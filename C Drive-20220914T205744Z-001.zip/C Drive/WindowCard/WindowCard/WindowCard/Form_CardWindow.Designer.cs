﻿namespace WindowCard
{
    partial class Form_CardWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label snoLabel;
            System.Windows.Forms.Label cardnumLabel;
            System.Windows.Forms.Label cnameLabel;
            System.Windows.Forms.Label dobLabel;
            System.Windows.Forms.Label deptidLabel;
            System.Windows.Forms.Label pdateLabel;
            System.Windows.Forms.Label cidLabel;
            System.Windows.Forms.Label cstatusLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_CardWindow));
            this.Label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox_tAmount = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_RejectCard = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_ActualCard = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label_TrueCard = new System.Windows.Forms.Label();
            this.label_tc = new System.Windows.Forms.Label();
            this.label_FalseCard = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button_InsertMonthlyReport = new System.Windows.Forms.Button();
            this.textBox_ShortAmount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_ExcessAmount = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label_TotalCard = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label_heading = new System.Windows.Forms.Label();
            this.button_FalseCard = new System.Windows.Forms.Button();
            this.button_PrintDailyReport = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.button_Load = new System.Windows.Forms.Button();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.card_dataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cardDataSet1 = new WindowCard.cardDataSet1();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.snoTextBox = new System.Windows.Forms.TextBox();
            this.cardnumTextBox = new System.Windows.Forms.TextBox();
            this.cnameTextBox = new System.Windows.Forms.TextBox();
            this.dobTextBox = new System.Windows.Forms.TextBox();
            this.deptidTextBox = new System.Windows.Forms.TextBox();
            this.pdateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cidTextBox = new System.Windows.Forms.TextBox();
            this.cstatusCheckBox = new System.Windows.Forms.CheckBox();
            this.card_dataDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button_MonthlyReport = new System.Windows.Forms.Button();
            this.dateTimePickerFrom = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerTo = new System.Windows.Forms.DateTimePicker();
            this.crystalReportViewer_MonthlyReport = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.card_dataTableAdapter = new WindowCard.cardDataSet1TableAdapters.card_dataTableAdapter();
            this.tableAdapterManager1 = new WindowCard.cardDataSet1TableAdapters.TableAdapterManager();
            this.cardDataSet = new WindowCard.cardDataSet();
            this.card_dailytotalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.card_dailytotalTableAdapter = new WindowCard.cardDataSetTableAdapters.card_dailytotalTableAdapter();
            this.tableAdapterManager = new WindowCard.cardDataSetTableAdapters.TableAdapterManager();
            snoLabel = new System.Windows.Forms.Label();
            cardnumLabel = new System.Windows.Forms.Label();
            cnameLabel = new System.Windows.Forms.Label();
            dobLabel = new System.Windows.Forms.Label();
            deptidLabel = new System.Windows.Forms.Label();
            pdateLabel = new System.Windows.Forms.Label();
            cidLabel = new System.Windows.Forms.Label();
            cstatusLabel = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.card_dataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_dataDataGridView)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cardDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_dailytotalBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // snoLabel
            // 
            snoLabel.AutoSize = true;
            snoLabel.Location = new System.Drawing.Point(37, 23);
            snoLabel.Name = "snoLabel";
            snoLabel.Size = new System.Drawing.Size(34, 13);
            snoLabel.TabIndex = 1;
            snoLabel.Text = "S No:";
            // 
            // cardnumLabel
            // 
            cardnumLabel.AutoSize = true;
            cardnumLabel.Location = new System.Drawing.Point(37, 49);
            cardnumLabel.Name = "cardnumLabel";
            cardnumLabel.Size = new System.Drawing.Size(49, 13);
            cardnumLabel.TabIndex = 3;
            cardnumLabel.Text = "Card No:";
            // 
            // cnameLabel
            // 
            cnameLabel.AutoSize = true;
            cnameLabel.Location = new System.Drawing.Point(37, 79);
            cnameLabel.Name = "cnameLabel";
            cnameLabel.Size = new System.Drawing.Size(38, 13);
            cnameLabel.TabIndex = 5;
            cnameLabel.Text = "Name:";
            // 
            // dobLabel
            // 
            dobLabel.AutoSize = true;
            dobLabel.Location = new System.Drawing.Point(395, 23);
            dobLabel.Name = "dobLabel";
            dobLabel.Size = new System.Drawing.Size(33, 13);
            dobLabel.TabIndex = 7;
            dobLabel.Text = "DOB:";
            // 
            // deptidLabel
            // 
            deptidLabel.AutoSize = true;
            deptidLabel.Location = new System.Drawing.Point(395, 49);
            deptidLabel.Name = "deptidLabel";
            deptidLabel.Size = new System.Drawing.Size(47, 13);
            deptidLabel.TabIndex = 9;
            deptidLabel.Text = "Dept ID:";
            // 
            // pdateLabel
            // 
            pdateLabel.AutoSize = true;
            pdateLabel.Location = new System.Drawing.Point(586, 48);
            pdateLabel.Name = "pdateLabel";
            pdateLabel.Size = new System.Drawing.Size(33, 13);
            pdateLabel.TabIndex = 11;
            pdateLabel.Text = "Date:";
            // 
            // cidLabel
            // 
            cidLabel.AutoSize = true;
            cidLabel.Location = new System.Drawing.Point(395, 79);
            cidLabel.Name = "cidLabel";
            cidLabel.Size = new System.Drawing.Size(47, 13);
            cidLabel.TabIndex = 13;
            cidLabel.Text = "Counter:";
            // 
            // cstatusLabel
            // 
            cstatusLabel.AutoSize = true;
            cstatusLabel.Location = new System.Drawing.Point(586, 80);
            cstatusLabel.Name = "cstatusLabel";
            cstatusLabel.Size = new System.Drawing.Size(40, 13);
            cstatusLabel.TabIndex = 15;
            cstatusLabel.Text = "Status:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.ForestGreen;
            this.Label1.Location = new System.Drawing.Point(380, 9);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(264, 44);
            this.Label1.TabIndex = 57;
            this.Label1.Text = "CIVIL HOSPITAL KARACHI\r\nCARD PRINTING APPLICATION";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 84);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(980, 684);
            this.tabControl1.TabIndex = 58;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.textBox_tAmount);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.textBox_RejectCard);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.textBox_ActualCard);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label_TrueCard);
            this.tabPage1.Controls.Add(this.label_tc);
            this.tabPage1.Controls.Add(this.label_FalseCard);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.button_InsertMonthlyReport);
            this.tabPage1.Controls.Add(this.textBox_ShortAmount);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.textBox_ExcessAmount);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label_TotalCard);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label_heading);
            this.tabPage1.Controls.Add(this.button_FalseCard);
            this.tabPage1.Controls.Add(this.button_PrintDailyReport);
            this.tabPage1.Controls.Add(this.button_Update);
            this.tabPage1.Controls.Add(this.button_Load);
            this.tabPage1.Controls.Add(this.bindingNavigator1);
            this.tabPage1.Controls.Add(snoLabel);
            this.tabPage1.Controls.Add(this.snoTextBox);
            this.tabPage1.Controls.Add(cardnumLabel);
            this.tabPage1.Controls.Add(this.cardnumTextBox);
            this.tabPage1.Controls.Add(cnameLabel);
            this.tabPage1.Controls.Add(this.cnameTextBox);
            this.tabPage1.Controls.Add(dobLabel);
            this.tabPage1.Controls.Add(this.dobTextBox);
            this.tabPage1.Controls.Add(deptidLabel);
            this.tabPage1.Controls.Add(this.deptidTextBox);
            this.tabPage1.Controls.Add(pdateLabel);
            this.tabPage1.Controls.Add(this.pdateDateTimePicker);
            this.tabPage1.Controls.Add(cidLabel);
            this.tabPage1.Controls.Add(this.cidTextBox);
            this.tabPage1.Controls.Add(cstatusLabel);
            this.tabPage1.Controls.Add(this.cstatusCheckBox);
            this.tabPage1.Controls.Add(this.card_dataDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(972, 658);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Update Card";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox_tAmount
            // 
            this.textBox_tAmount.Location = new System.Drawing.Point(859, 333);
            this.textBox_tAmount.Name = "textBox_tAmount";
            this.textBox_tAmount.Size = new System.Drawing.Size(68, 20);
            this.textBox_tAmount.TabIndex = 39;
            this.textBox_tAmount.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(764, 336);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 13);
            this.label10.TabIndex = 38;
            this.label10.Text = "Amount Recvd:";
            // 
            // textBox_RejectCard
            // 
            this.textBox_RejectCard.Location = new System.Drawing.Point(859, 298);
            this.textBox_RejectCard.Name = "textBox_RejectCard";
            this.textBox_RejectCard.Size = new System.Drawing.Size(43, 20);
            this.textBox_RejectCard.TabIndex = 37;
            this.textBox_RejectCard.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(764, 301);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 13);
            this.label9.TabIndex = 36;
            this.label9.Text = "Reject Card:";
            // 
            // textBox_ActualCard
            // 
            this.textBox_ActualCard.Location = new System.Drawing.Point(859, 258);
            this.textBox_ActualCard.Name = "textBox_ActualCard";
            this.textBox_ActualCard.Size = new System.Drawing.Size(43, 20);
            this.textBox_ActualCard.TabIndex = 35;
            this.textBox_ActualCard.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(764, 261);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 34;
            this.label8.Text = "Actual Card:";
            // 
            // label_TrueCard
            // 
            this.label_TrueCard.AutoSize = true;
            this.label_TrueCard.Location = new System.Drawing.Point(856, 176);
            this.label_TrueCard.Name = "label_TrueCard";
            this.label_TrueCard.Size = new System.Drawing.Size(13, 13);
            this.label_TrueCard.TabIndex = 33;
            this.label_TrueCard.Text = "0";
            // 
            // label_tc
            // 
            this.label_tc.AutoSize = true;
            this.label_tc.Location = new System.Drawing.Point(764, 176);
            this.label_tc.Name = "label_tc";
            this.label_tc.Size = new System.Drawing.Size(57, 13);
            this.label_tc.TabIndex = 32;
            this.label_tc.Text = "True Card:";
            // 
            // label_FalseCard
            // 
            this.label_FalseCard.AutoSize = true;
            this.label_FalseCard.Location = new System.Drawing.Point(856, 220);
            this.label_FalseCard.Name = "label_FalseCard";
            this.label_FalseCard.Size = new System.Drawing.Size(13, 13);
            this.label_FalseCard.TabIndex = 31;
            this.label_FalseCard.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(764, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 30;
            this.label7.Text = "False Card:";
            // 
            // button_InsertMonthlyReport
            // 
            this.button_InsertMonthlyReport.Location = new System.Drawing.Point(801, 479);
            this.button_InsertMonthlyReport.Name = "button_InsertMonthlyReport";
            this.button_InsertMonthlyReport.Size = new System.Drawing.Size(89, 22);
            this.button_InsertMonthlyReport.TabIndex = 29;
            this.button_InsertMonthlyReport.Text = "Insert in Report";
            this.button_InsertMonthlyReport.UseVisualStyleBackColor = true;
            this.button_InsertMonthlyReport.Click += new System.EventHandler(this.button_InsertMonthlyReport_Click);
            // 
            // textBox_ShortAmount
            // 
            this.textBox_ShortAmount.Location = new System.Drawing.Point(859, 408);
            this.textBox_ShortAmount.Name = "textBox_ShortAmount";
            this.textBox_ShortAmount.Size = new System.Drawing.Size(43, 20);
            this.textBox_ShortAmount.TabIndex = 28;
            this.textBox_ShortAmount.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(764, 411);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "Short Amount:";
            // 
            // textBox_ExcessAmount
            // 
            this.textBox_ExcessAmount.Location = new System.Drawing.Point(859, 369);
            this.textBox_ExcessAmount.Name = "textBox_ExcessAmount";
            this.textBox_ExcessAmount.Size = new System.Drawing.Size(43, 20);
            this.textBox_ExcessAmount.TabIndex = 26;
            this.textBox_ExcessAmount.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(764, 372);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Excess Amount:";
            // 
            // label_TotalCard
            // 
            this.label_TotalCard.AutoSize = true;
            this.label_TotalCard.Location = new System.Drawing.Point(856, 134);
            this.label_TotalCard.Name = "label_TotalCard";
            this.label_TotalCard.Size = new System.Drawing.Size(13, 13);
            this.label_TotalCard.TabIndex = 24;
            this.label_TotalCard.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(764, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Total Card:";
            // 
            // label_heading
            // 
            this.label_heading.AutoSize = true;
            this.label_heading.BackColor = System.Drawing.Color.PaleGreen;
            this.label_heading.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_heading.Location = new System.Drawing.Point(20, 106);
            this.label_heading.Name = "label_heading";
            this.label_heading.Size = new System.Drawing.Size(0, 20);
            this.label_heading.TabIndex = 22;
            // 
            // button_FalseCard
            // 
            this.button_FalseCard.Location = new System.Drawing.Point(425, 598);
            this.button_FalseCard.Name = "button_FalseCard";
            this.button_FalseCard.Size = new System.Drawing.Size(75, 23);
            this.button_FalseCard.TabIndex = 21;
            this.button_FalseCard.Text = "Show False";
            this.button_FalseCard.UseVisualStyleBackColor = true;
            this.button_FalseCard.Click += new System.EventHandler(this.button_FalseCard_Click);
            // 
            // button_PrintDailyReport
            // 
            this.button_PrintDailyReport.Location = new System.Drawing.Point(524, 598);
            this.button_PrintDailyReport.Name = "button_PrintDailyReport";
            this.button_PrintDailyReport.Size = new System.Drawing.Size(113, 23);
            this.button_PrintDailyReport.TabIndex = 20;
            this.button_PrintDailyReport.Text = "Show Daily Report";
            this.button_PrintDailyReport.UseVisualStyleBackColor = true;
            this.button_PrintDailyReport.Click += new System.EventHandler(this.button_PrintDailyReport_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(340, 598);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(61, 23);
            this.button_Update.TabIndex = 19;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // button_Load
            // 
            this.button_Load.Location = new System.Drawing.Point(262, 598);
            this.button_Load.Name = "button_Load";
            this.button_Load.Size = new System.Drawing.Size(52, 23);
            this.button_Load.TabIndex = 18;
            this.button_Load.Text = "Load";
            this.button_Load.UseVisualStyleBackColor = true;
            this.button_Load.Click += new System.EventHandler(this.button_Load_Click);
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.BindingSource = this.card_dataBindingSource;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.bindingNavigator1.Location = new System.Drawing.Point(15, 596);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(210, 25);
            this.bindingNavigator1.TabIndex = 17;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // card_dataBindingSource
            // 
            this.card_dataBindingSource.DataMember = "card_data";
            this.card_dataBindingSource.DataSource = this.cardDataSet1;
            // 
            // cardDataSet1
            // 
            this.cardDataSet1.DataSetName = "cardDataSet1";
            this.cardDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // snoTextBox
            // 
            this.snoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.card_dataBindingSource, "Sno", true));
            this.snoTextBox.Location = new System.Drawing.Point(94, 20);
            this.snoTextBox.Name = "snoTextBox";
            this.snoTextBox.ReadOnly = true;
            this.snoTextBox.Size = new System.Drawing.Size(71, 20);
            this.snoTextBox.TabIndex = 2;
            // 
            // cardnumTextBox
            // 
            this.cardnumTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.card_dataBindingSource, "cardnum", true));
            this.cardnumTextBox.Location = new System.Drawing.Point(94, 46);
            this.cardnumTextBox.Name = "cardnumTextBox";
            this.cardnumTextBox.ReadOnly = true;
            this.cardnumTextBox.Size = new System.Drawing.Size(200, 20);
            this.cardnumTextBox.TabIndex = 4;
            // 
            // cnameTextBox
            // 
            this.cnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.card_dataBindingSource, "cname", true));
            this.cnameTextBox.Location = new System.Drawing.Point(94, 76);
            this.cnameTextBox.Name = "cnameTextBox";
            this.cnameTextBox.ReadOnly = true;
            this.cnameTextBox.Size = new System.Drawing.Size(270, 20);
            this.cnameTextBox.TabIndex = 6;
            // 
            // dobTextBox
            // 
            this.dobTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.card_dataBindingSource, "dob", true));
            this.dobTextBox.Location = new System.Drawing.Point(452, 20);
            this.dobTextBox.Name = "dobTextBox";
            this.dobTextBox.ReadOnly = true;
            this.dobTextBox.Size = new System.Drawing.Size(58, 20);
            this.dobTextBox.TabIndex = 8;
            // 
            // deptidTextBox
            // 
            this.deptidTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.card_dataBindingSource, "deptid", true));
            this.deptidTextBox.Location = new System.Drawing.Point(452, 46);
            this.deptidTextBox.Name = "deptidTextBox";
            this.deptidTextBox.ReadOnly = true;
            this.deptidTextBox.Size = new System.Drawing.Size(101, 20);
            this.deptidTextBox.TabIndex = 10;
            // 
            // pdateDateTimePicker
            // 
            this.pdateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.card_dataBindingSource, "pdate", true));
            this.pdateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.pdateDateTimePicker.Location = new System.Drawing.Point(638, 43);
            this.pdateDateTimePicker.Name = "pdateDateTimePicker";
            this.pdateDateTimePicker.Size = new System.Drawing.Size(101, 20);
            this.pdateDateTimePicker.TabIndex = 12;
            // 
            // cidTextBox
            // 
            this.cidTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.card_dataBindingSource, "cid", true));
            this.cidTextBox.Location = new System.Drawing.Point(453, 75);
            this.cidTextBox.Name = "cidTextBox";
            this.cidTextBox.ReadOnly = true;
            this.cidTextBox.Size = new System.Drawing.Size(76, 20);
            this.cidTextBox.TabIndex = 14;
            // 
            // cstatusCheckBox
            // 
            this.cstatusCheckBox.BackColor = System.Drawing.SystemColors.Highlight;
            this.cstatusCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.card_dataBindingSource, "cstatus", true));
            this.cstatusCheckBox.Location = new System.Drawing.Point(638, 78);
            this.cstatusCheckBox.Name = "cstatusCheckBox";
            this.cstatusCheckBox.Size = new System.Drawing.Size(28, 19);
            this.cstatusCheckBox.TabIndex = 16;
            this.cstatusCheckBox.UseVisualStyleBackColor = false;
            // 
            // card_dataDataGridView
            // 
            this.card_dataDataGridView.AllowUserToAddRows = false;
            this.card_dataDataGridView.AllowUserToDeleteRows = false;
            this.card_dataDataGridView.AutoGenerateColumns = false;
            this.card_dataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.card_dataDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewCheckBoxColumn1});
            this.card_dataDataGridView.DataSource = this.card_dataBindingSource;
            this.card_dataDataGridView.Location = new System.Drawing.Point(15, 129);
            this.card_dataDataGridView.Name = "card_dataDataGridView";
            this.card_dataDataGridView.ReadOnly = true;
            this.card_dataDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.card_dataDataGridView.Size = new System.Drawing.Size(724, 436);
            this.card_dataDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Sno";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 59;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "cardnum";
            this.dataGridViewTextBoxColumn2.HeaderText = "Card No";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 110;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "cname";
            this.dataGridViewTextBoxColumn3.HeaderText = "Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "dob";
            this.dataGridViewTextBoxColumn4.HeaderText = "DOB";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 70;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "deptid";
            this.dataGridViewTextBoxColumn5.HeaderText = "Depart";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 60;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "pdate";
            this.dataGridViewTextBoxColumn6.HeaderText = "Date";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 80;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "cid";
            this.dataGridViewTextBoxColumn7.HeaderText = "Counter";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 60;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "cstatus";
            this.dataGridViewCheckBoxColumn1.HeaderText = "Status";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            this.dataGridViewCheckBoxColumn1.Width = 60;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.crystalReportViewer1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(933, 658);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Report";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.DisplayGroupTree = false;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewer1.Location = new System.Drawing.Point(3, 3);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.SelectionFormula = "";
            this.crystalReportViewer1.Size = new System.Drawing.Size(927, 652);
            this.crystalReportViewer1.TabIndex = 0;
            this.crystalReportViewer1.ViewTimeSelectionFormula = "";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.button_MonthlyReport);
            this.tabPage3.Controls.Add(this.dateTimePickerFrom);
            this.tabPage3.Controls.Add(this.dateTimePickerTo);
            this.tabPage3.Controls.Add(this.crystalReportViewer_MonthlyReport);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(933, 658);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Monthly Report";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(247, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "From:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(90, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To:";
            // 
            // button_MonthlyReport
            // 
            this.button_MonthlyReport.Location = new System.Drawing.Point(439, 29);
            this.button_MonthlyReport.Name = "button_MonthlyReport";
            this.button_MonthlyReport.Size = new System.Drawing.Size(106, 23);
            this.button_MonthlyReport.TabIndex = 3;
            this.button_MonthlyReport.Text = "Show Report";
            this.button_MonthlyReport.UseVisualStyleBackColor = true;
            this.button_MonthlyReport.Click += new System.EventHandler(this.button_MonthlyReport_Click);
            // 
            // dateTimePickerFrom
            // 
            this.dateTimePickerFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerFrom.Location = new System.Drawing.Point(285, 30);
            this.dateTimePickerFrom.Name = "dateTimePickerFrom";
            this.dateTimePickerFrom.Size = new System.Drawing.Size(110, 20);
            this.dateTimePickerFrom.TabIndex = 2;
            // 
            // dateTimePickerTo
            // 
            this.dateTimePickerTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerTo.Location = new System.Drawing.Point(117, 30);
            this.dateTimePickerTo.Name = "dateTimePickerTo";
            this.dateTimePickerTo.Size = new System.Drawing.Size(104, 20);
            this.dateTimePickerTo.TabIndex = 1;
            // 
            // crystalReportViewer_MonthlyReport
            // 
            this.crystalReportViewer_MonthlyReport.ActiveViewIndex = -1;
            this.crystalReportViewer_MonthlyReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer_MonthlyReport.DisplayGroupTree = false;
            this.crystalReportViewer_MonthlyReport.Location = new System.Drawing.Point(6, 69);
            this.crystalReportViewer_MonthlyReport.Name = "crystalReportViewer_MonthlyReport";
            this.crystalReportViewer_MonthlyReport.SelectionFormula = "";
            this.crystalReportViewer_MonthlyReport.Size = new System.Drawing.Size(921, 583);
            this.crystalReportViewer_MonthlyReport.TabIndex = 0;
            this.crystalReportViewer_MonthlyReport.ViewTimeSelectionFormula = "";
            // 
            // card_dataTableAdapter
            // 
            this.card_dataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.card_dataTableAdapter = this.card_dataTableAdapter;
            this.tableAdapterManager1.UpdateOrder = WindowCard.cardDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // cardDataSet
            // 
            this.cardDataSet.DataSetName = "cardDataSet";
            this.cardDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // card_dailytotalBindingSource
            // 
            this.card_dailytotalBindingSource.DataMember = "card_dailytotal";
            this.card_dailytotalBindingSource.DataSource = this.cardDataSet;
            // 
            // card_dailytotalTableAdapter
            // 
            this.card_dailytotalTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.card_dailytotalTableAdapter = this.card_dailytotalTableAdapter;
            this.tableAdapterManager.UpdateOrder = WindowCard.cardDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // Form_CardWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 780);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.Label1);
            this.Name = "Form_CardWindow";
            this.Text = "Window Card Application";
            this.Load += new System.EventHandler(this.Form_CardWindow_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.card_dataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_dataDataGridView)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cardDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_dailytotalBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label1;
        private cardDataSet cardDataSet;
        private System.Windows.Forms.BindingSource card_dailytotalBindingSource;
        private WindowCard.cardDataSetTableAdapters.card_dailytotalTableAdapter card_dailytotalTableAdapter;
        private WindowCard.cardDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private cardDataSet1 cardDataSet1;
        private System.Windows.Forms.BindingSource card_dataBindingSource;
        private WindowCard.cardDataSet1TableAdapters.card_dataTableAdapter card_dataTableAdapter;
        private WindowCard.cardDataSet1TableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.TextBox snoTextBox;
        private System.Windows.Forms.TextBox cardnumTextBox;
        private System.Windows.Forms.TextBox cnameTextBox;
        private System.Windows.Forms.TextBox dobTextBox;
        private System.Windows.Forms.TextBox deptidTextBox;
        private System.Windows.Forms.DateTimePicker pdateDateTimePicker;
        private System.Windows.Forms.TextBox cidTextBox;
        private System.Windows.Forms.CheckBox cstatusCheckBox;
        private System.Windows.Forms.DataGridView card_dataDataGridView;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.Button button_PrintDailyReport;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Button button_Load;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        private System.Windows.Forms.Button button_FalseCard;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_MonthlyReport;
        private System.Windows.Forms.DateTimePicker dateTimePickerFrom;
        private System.Windows.Forms.DateTimePicker dateTimePickerTo;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer_MonthlyReport;
        private System.Windows.Forms.Label label_heading;
        private System.Windows.Forms.Label label_TotalCard;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_InsertMonthlyReport;
        private System.Windows.Forms.TextBox textBox_ShortAmount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_ExcessAmount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_FalseCard;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_tc;
        private System.Windows.Forms.Label label_TrueCard;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.TextBox textBox_tAmount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_RejectCard;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_ActualCard;
        private System.Windows.Forms.Label label8;

    }
}