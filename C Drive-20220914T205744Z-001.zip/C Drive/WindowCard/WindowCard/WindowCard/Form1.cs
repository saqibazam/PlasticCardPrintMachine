﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowCard
{
    public partial class Form_Login : Form
    {
        public Form_Login()
        {
            InitializeComponent();
            txtName.Focus();
        }

        private void bttnLogin_Click(object sender, EventArgs e)
        {
            LoginCheck();
        }

        private void LoginCheck()
        {
            if (txtName.Text == "Admin" & txtPass.Text == "SunBeamImpact")
            {
                // MessageBox.Show("***************Welcome***************");

                // this.Hide();
                this.Visible = false;
                Form_CardWindow fw = new Form_CardWindow();
                fw.Show();
                //frmLogin fl = new frmLogin();
                //fl.Close();
                //fl.Dispose();
            }
            else
            {
                MessageBox.Show("INVALID USER NAME OR PASSWORD", "INVALID PASSWORD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtName.Focus();
                txtName.SelectionStart = 0;
                txtName.SelectionLength = txtName.Text.Length;
                txtPass.Text = "";
            }
        }

        private void txtPass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                //bttnLogin.Focus();
                LoginCheck();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPass.Focus();
            }
        }

        private void Form_Login_Load(object sender, EventArgs e)
        {
            txtName.Focus();
        }
    }
}
